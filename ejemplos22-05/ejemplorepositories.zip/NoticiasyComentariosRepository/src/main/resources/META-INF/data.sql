INSERT INTO Noticia (titulo, autor, fecha) VALUES ('Por fin lunes', 'pepito', '2021-03-22');
INSERT INTO Comentario (texto,autor, noticia_titulo) VALUES ('que bien','manolito','Por fin lunes')